const menuBtn = document.getElementById("menu-btn");
const navLinks = document.getElementById("nav-links");
const menuBtnIcon = menuBtn.querySelector("i");

menuBtn.addEventListener("click", (e) => {
  navLinks.classList.toggle("open");

  const isOpen = navLinks.classList.contains("open");
  menuBtnIcon.setAttribute("class", isOpen ? "ri-close-line" : "ri-menu-line");
});



const scrollRevealOption = {
  distance: "50px",
  origin: "bottom",
  duration: 1000,
};



// this where a logical code is there
document.getElementById('emailForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const emailContent = document.getElementById('emailContent').value;
    const response = await fetch('http://127.0.0.1:5006/detect_spam', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email_content: emailContent })
    });
    const data = await response.json();
    document.getElementById('result').innerText = `Prediction: ${data.prediction}`;
});