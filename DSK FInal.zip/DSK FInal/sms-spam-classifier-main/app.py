import pickle
import string
from flask import Flask, request, jsonify
from flask_cors import CORS
import nltk
from nltk.stem.porter import PorterStemmer

# Download NLTK stopwords resource
nltk.download('stopwords')

# Load the trained model and vectorizer
with open('model.pkl', 'rb') as f:
    model = pickle.load(f)

with open('vectorizer.pkl', 'rb') as f:
    vectorizer = pickle.load(f)

ps = PorterStemmer()

app = Flask(__name__)
CORS(app)

def transform_text(text):
    text = text.lower()
    text = nltk.word_tokenize(text)

    y = []
    for i in text:
        if i.isalnum():
            y.append(i)

    text = y[:]
    y.clear()

    stopwords_set = set(nltk.corpus.stopwords.words('english'))
    for i in text:
        if i not in stopwords_set and i not in string.punctuation:
            y.append(i)

    text = y[:]
    y.clear()

    for i in text:
        y.append(ps.stem(i))

    return " ".join(y)

@app.route('/detect_spam', methods=['POST'])
def detect_spam():
    email_content = request.json['email_content']
    # Preprocess the email content
    transformed_email = transform_text(email_content)
    # Vectorize the preprocessed email content
    email_vector = vectorizer.transform([transformed_email])
    # Predict using the model
    prediction = model.predict(email_vector)[0]
    result = "Spam" if prediction == 1 else "Not Spam"
    return jsonify({'prediction': result})

if __name__ == '__main__':
    app.run(port=5006, debug=True)
